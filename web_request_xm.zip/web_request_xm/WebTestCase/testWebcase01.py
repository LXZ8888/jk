'''xx2模块的web自动化用例：
不需要登录的
'''
from PO.loginpage import LoginPage
from PO.homepage import HomePage
#
# class TestCase02(HomePage):
#     '''
#     TestCase是用例类
#     '''
#     def test_search02(self,browserInit):
#         self.search(browserInit,'包包')
